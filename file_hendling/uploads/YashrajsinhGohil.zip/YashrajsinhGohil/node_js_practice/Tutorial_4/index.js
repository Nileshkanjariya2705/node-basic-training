require('dotenv').config();
const express = require('express');
const app = express();
const path = require('path');
const connection = require('./db');
const { error, log } = require('console');
const { title } = require('process');
const PORT = process.env.PORT;

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.get('/', async (req, res) => {
    // const[data] = await connection.query('SELECT * FROM applicant_details');
    res.render('form', {
        title: 'JOB APPLICATION FORM',
        submittionPath: '/applicants/create',
        method: 'POST',
        isEditMode: false
    });
});

app.post('/applicants/create', async (req, res) => {
    try {
        const data = req.body;

        //Inseting basic details through sql query connection.
        const [result] = await connection.query(
            `INSERT INTO applicant_details 
                        (first_name, last_name, designation, email, phone, address1, address2, city, state, zip_code, gender, relationship_status, dob)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?);`,
            [
                data.fName,
                data.lName,
                data.companyPosition,
                data.email,
                data.contact,
                data.addressLine1,
                data.addressLine2,
                data.city,
                data.states,
                data.zipcode,
                data.gender,
                data.relationshipStatus,
                data.dateOfBirth
            ]
        );
        // console.log(result);
        const applicantID = result.insertId;

        //Inserting data to the database for the education details
        if (data.field.length > 0) {
            for (let i = 0; i < data.percentage.length; i++) {
                await connection.query(`
                    INSERT INTO education_details (applicant_id, education_level, course_name, university_board, passing_year, percentage) VALUES (?, ?, ?, ?, ?, ?)`,
                    [
                        applicantID,
                        data.field[i] || null,
                        data.courseName[i - 2] || null,
                        data.boardName_university[i] || null,
                        data.passingYear[i] || null,
                        data.percentage[i] || null
                    ]
                );
            }
        } else {
            throw new error(() => {
                res.send('There was not any data to be inserted into the data')
            })
        }

        if (data.companyName.length > 0) {
            for (let i = 0; i < data.companyName.length; i++) {
                await connection.query(
                    `INSERT INTO job_application_details.work_experience
                    (applicant_id,
                    company_name,
                    designation,
                    from_date,
                    to_date)
                    VALUES
                    (?, ?, ?, ?, ?);
                    `,
                    [
                        applicantID,
                        data.companyName[i] || null,
                        data.designation[i] || null,
                        data.fromDate[i] || null,
                        data.toDate[i] || null
                    ]
                );
            }
        } else {
            throw new error(console.log('Error occured in inserting work experience'));
        }

        let [langArr] = await connection.query('SELECT language_id, language_name FROM languages;');
        // console.log(langArr);

        for (let i = 0; i < langArr.length; i++) {
            if (langArr[i].language_name in data) {
                // console.log(data[langArr[i].language_name]);

                const can_speak = data[langArr[i].language_name].includes('speak');
                const can_read = data[langArr[i].language_name].includes('read');
                const can_write = data[langArr[i].language_name].includes('write');

                await connection.query(
                    `INSERT INTO applicant_languages
                (applicant_id, language_id, can_read, can_write, can_speak)
                VALUES
                (?, ?, ?, ?, ?);`,
                    [
                        applicantID,
                        langArr[i].language_id,
                        can_read ? 1 : 0,
                        can_write ? 1 : 0,
                        can_speak ? 1 : 0
                    ]
                );
            } else {
                await connection.query(
                    `INSERT INTO applicant_languages
                (applicant_id, language_id, can_read, can_write, can_speak)
                VALUES
                (?, ?, ?, ?, ?);`,
                    [
                        applicantID,
                        langArr[i].language_id,
                        0,
                        0,
                        0
                    ]
                );
            }
        }

        const [technologies] = await connection.query(`SELECT tech_id, tech_name FROM technologies;`);
        // console.log(technologies);

        for (let i = 0; i < technologies.length; i++) {
            if (technologies[i].tech_name in data) {
                await connection.query(
                    `INSERT INTO applicant_technologies
                (applicant_id, tech_id, proficiency)
                VALUES
                (?, ?, ?)`,
                    [
                        applicantID,
                        technologies[i].tech_id,
                        data[technologies[i].tech_name] || 'Beginner'
                    ]
                );
            }
        }

        for (let i = 0; i < data.refererName.length; i++) {
            await connection.query(
                `INSERT INTO references_contact 
            (applicant_id, name, contact_number, relation)
            VALUES
            (?, ?, ?, ?);`,
                [
                    applicantID,
                    data.refererName[i] || null,
                    data.contactNumber[i] || null,
                    data.referRealtion[i] || null
                ]
            );
        }

        await connection.query(
            `INSERT INTO preferences
        (applicant_id, preferred_location1, preferred_location2, preferred_location3, notice_period, department, current_ctc, expected_ctc)
        VALUES
        (? ,? ,? ,? ,? ,? ,? ,?)`,
            [
                applicantID,
                data.preferedLocation[0] || null,
                data.preferedLocation[1] || null,
                data.preferedLocation[2] || null,
                data.noticePeriod,
                data.departments,
                data.currentCTC,
                data.expectedCTC
            ]
        );

        res.render('view');
    } catch (err) {
        res.send('An occured while processing your request')
    } finally {
        connection.releaseConnection();
    }
});

app.get('/applicants/view/', async (req, res) => {
    const [basicDetails] = await connection.query(`SELECT applicant_id, first_name, last_name, designation, email, phone, city FROM applicant_details`);
    // console.log(basicDetails);
    res.render('view', {
        title: 'List Of Applicants',
        basicDetails
    });
});

app.get('/applicants/view/:id', async (req, res) => {
    try {
        const applicant_id = req.params.id;

        const [basicDetails] = await connection.query(
            `SELECT applicant_id, first_name, last_name, designation, email, phone, address1, address2, city, state, zip_code, gender, relationship_status, DATE_FORMAT(dob, '%Y-%m-%d') AS dob FROM applicant_details WHERE applicant_id = ?;`, [applicant_id]
        );

        const [education_details] = await connection.query(
            `SELECT * FROM education_details WHERE applicant_id = ?;`, [applicant_id]
        );

        const [workExperience] = await connection.query(
            `SELECT company_name, designation, DATE_FORMAT(from_date, '%Y-%m-%d') AS from_date, DATE_FORMAT(to_date, '%Y-%m-%d') AS to_date FROM work_experience WHERE applicant_id = ?;`, [applicant_id]
        );

        const [languagesKnown] = await connection.query(
            `SELECT l.language_name , lk.can_read, lk.can_write, lk.can_speak FROM languages l JOIN applicant_languages lk ON l.language_id = lk.language_id WHERE lk.applicant_id = ?`, [applicant_id]
        );

        const [technologiesKnown] = await connection.query(
            `SELECT 
             t.tech_name, tk.proficiency 
             FROM technologies t 
             JOIN applicant_technologies tk 
             ON t.tech_id = tk.tech_id 
             WHERE tk.applicant_id = ?;`, [applicant_id]
        );

        const [references] = await connection.query(
            `SELECT * FROM references_contact WHERE applicant_id = ?`, [applicant_id]
        );

        const [prefrences] = await connection.query(
            `SELECT * FROM preferences WHERE applicant_id = ?`, [applicant_id]
        );

        // console.log(basicDetails,
        //     education_details,
        //     workExperience,
        //     languagesKnown,
        //     technologiesKnown,
        //     references,
        //     prefrences
        // );

        res.render('expand', {
            basicDetails,
            education_details,
            workExperience,
            languagesKnown,
            technologiesKnown,
            references,
            prefrences
        });
    } catch (err) {
        res.send({
            errMessage: 'An error occured while handling your request',
            Error: err
        })
    }
});

app.get('/applicants/edit/:id', async (req, res) => {
    const applicant_id = req.params.id;

    const [basicDetails] = await connection.query(
        `SELECT applicant_id, first_name, last_name, designation, email, phone, address1, address2, city, state, zip_code, gender, relationship_status, DATE_FORMAT(dob, '%Y-%m-%d') AS dob FROM applicant_details WHERE applicant_id = ?;`, [applicant_id]
    );

    const [education_details] = await connection.query(
        `SELECT * FROM education_details WHERE applicant_id = ?;`, [applicant_id]
    );

    const [workExperience] = await connection.query(
        `SELECT company_name, designation, DATE_FORMAT(from_date, '%Y-%m-%d') AS from_date, DATE_FORMAT(to_date, '%Y-%m-%d') AS to_date FROM work_experience WHERE applicant_id = ?;`, [applicant_id]
    );

    const [languagesKnown] = await connection.query(
        `SELECT l.language_name , lk.can_read, lk.can_write, lk.can_speak FROM languages l JOIN applicant_languages lk ON l.language_id = lk.language_id WHERE lk.applicant_id = ?`, [applicant_id]
    );

    const [technologiesKnown] = await connection.query(
        `SELECT 
             t.tech_name, tk.proficiency 
             FROM technologies t 
             JOIN applicant_technologies tk 
             ON t.tech_id = tk.tech_id 
             WHERE tk.applicant_id = ?;`, [applicant_id]
    );

    const [references] = await connection.query(
        `SELECT * FROM references_contact WHERE applicant_id = ?`, [applicant_id]
    );

    const [prefrences] = await connection.query(
        `SELECT * FROM preferences WHERE applicant_id = ?`, [applicant_id]
    );


    res.render('form', {
        submittionPath: `/applicants/update/${applicant_id}`,
        method: 'POST',
        isEditMode: true,
        title: 'Edit Form',
        basicDetails,
        education_details,
        workExperience,
        languagesKnown,
        technologiesKnown,
        references,
        prefrences,
        button: 'Update'
    });
});

app.post('/applicants/update/:id', async (req, res) => {
    const data = req.body;
    const application_id = req.params.id;

    //Updating basicDetails
    const [basicDetailsUpdate] = await connection.query(
        `UPDATE applicant_details
         SET
         first_name = ?,
         last_name = ?,
         designation = ?,
         email = ?,
         phone = ?,
         address1 = ?,
         address2 = ?,
         city = ?,
         state = ?,
         zip_code = ?,
         gender = ?,
         relationship_status = ?,
         dob = ?
         WHERE applicant_id = ?;`,
        [
            data.fName,
            data.lName,
            data.companyPosition,
            data.email,
            data.contact,
            data.addressLine1,
            data.addressLine2,
            data.city,
            data.states,
            data.zipcode,
            data.gender,
            data.relationshipStatus,
            data.dateOfBirth,
            application_id
        ]
    );

    if (basicDetailsUpdate) {
        console.log('Basic details inserted successfully!');

    }

    const [deleteOldEducationDetails] = await connection.query(
        `DELETE FROM education_details WHERE applicant_id = ?`,
        [application_id]
    );

    if (deleteOldEducationDetails) {
        console.log('Old Data deleted successfully');
    }

    //Education details
    if (data.field) {
        for (let i = 0; i < data.percentage.length; i++) {
            await connection.query(`
                INSERT INTO education_details (applicant_id, education_level, course_name, university_board, passing_year, percentage) VALUES (?, ?, ?, ?, ?, ?)`,
                [
                    application_id,
                    data.field[i] || null,
                    data.courseName[i - 2] || null,
                    data.boardName_university[i] || null,
                    data.passingYear[i] || null,
                    data.percentage[i] || null
                ]
            );
        }
    } else {
        throw new error(() => {
            res.send('There was not any data to be inserted into the data')
        })
    }

    const [deleteWorkExperience] = await connection.query(
        `DELETE FROM work_experience WHERE applicant_id = ?`,
        [application_id]
    );

    if (deleteWorkExperience) {
        console.log('WorkExperience was deleted successfully');
    }

    //Updating work experience
    if (data.companyName) {
        for (let i = 0; i < data.companyName.length; i++) {
            await connection.query(
                `INSERT INTO work_experience
                (applicant_id,
                company_name,
                designation,
                from_date,
                to_date)
                VALUES
                (?, ?, ?, ?, ?);
                `,
                [
                    application_id,
                    data.companyName[i] || null,
                    data.designation[i] || null,
                    data.fromDate[i] || null,
                    data.toDate[i] || null
                ]
            );
        }

        console.log('Your new data was inserted successfully');

    } else {
        throw new error(console.log('Error occured in inserting work experience'));
    }

    const [deleteKnownLanguges] = await connection.query(
        `DELETE FROM applicant_languages WHERE applicant_id = ?`,
        [application_id]
    );

    if (deleteKnownLanguges) {
        console.log('Your old languages are deleted');
    }

    //Updating languages
    let [langArr] = await connection.query('SELECT language_id, language_name FROM languages;');
    // console.log(langArr);

    for (let i = 0; i < langArr.length; i++) {
        if (langArr[i].language_name in data) {
            // console.log(data[langArr[i].language_name]);

            const can_speak = data[langArr[i].language_name].includes('speak');
            const can_read = data[langArr[i].language_name].includes('read');
            const can_write = data[langArr[i].language_name].includes('write');

            await connection.query(
                `INSERT INTO applicant_languages
                 (applicant_id, language_id, can_read, can_write, can_speak)
                 VALUES
                 (?, ?, ?, ?, ?);`,
                [
                    application_id,
                    langArr[i].language_id,
                    can_read ? 1 : 0,
                    can_write ? 1 : 0,
                    can_speak ? 1 : 0
                ]
            );
        } else {
            await connection.query(
                `INSERT INTO applicant_languages
            (applicant_id, language_id, can_read, can_write, can_speak)
            VALUES
            (?, ?, ?, ?, ?);`,
                [
                    application_id,
                    langArr[i].language_id,
                    0,
                    0,
                    0
                ]
            );
        }
    }

    //Updating technologies
    const [technologies] = await connection.query(`SELECT tech_id, tech_name FROM technologies;`);
    // console.log(technologies);

    for (let i = 0; i < technologies.length; i++) {
        if (technologies[i].tech_name in data) {
            await connection.query(
                `UPDATE applicant_technologies
                 SET
                 proficiency = ?
                 WHERE applicant_id = ? AND tech_id = ?;`,
                [
                    data[technologies[i].tech_name],
                    application_id,
                    technologies[i].tech_id
                ]
            );
        }
    }

    const [deleteOldRef] = await connection.query('DELETE FROM references_contact WHERE applicant_id = ?', [application_id]);

    if(deleteOldRef) {
        console.log('DELETED old data successfully');
    }

    //Updating the references
    if(data.refererName) {
        for (let i = 0; i < data.refererName.length; i++) {
            await connection.query(
                `INSERT INTO references_contact 
                 (applicant_id, name, contact_number, relation)
                 VALUES
                 (?, ?, ?, ?);`,
                [
                    application_id,
                    data.refererName[i] || null,
                    data.contactNumber[i] || null,
                    data.referRealtion[i] || null
                ]
            );
        }
    }

    if(data.preferedLocation) {
        await connection.query(
           `UPDATE preferences
            SET
            preferred_location1 = ?,
            preferred_location2 = ?,
            preferred_location3 = ?,
            notice_period = ?,
            department = ?,
            current_ctc = ?,
            expected_ctc = ?
            WHERE applicant_id = ?`,
            [
                data.preferedLocation[0],
                data.preferedLocation[1],
                data.preferedLocation[2],
                data.noticePeriod,
                data.departments,
                data.currentCTC,
                data.expectedCTC,
                application_id
            ]
        );
    }

    

    console.log(data);
    res.send({
        message: 'Data Updated succesfully',
    })
});

app.get('/applicants/delete/:id', async (req, res) => {
    const applicantID = req.params.id;
    const result = await connection.query(
        'DELETE FROM applicant_details WHERE applicant_id = ?',
        [applicantID]
    );

    res.send({
        result,
        successMessage: 'The data was deleted successfully'
    });

    res.render('view');
});

app.use((req, res) => {
    res.redirect('/');
});
 
app.use((err, req, res, next) => {
    console.error('Server error:', err.message);
    res.redirect('/');
});

app.listen(PORT, () => {
    console.log('======================================================');
    console.log(`    Server is running on port: ${PORT}`);
    console.log(`    You can access it on link: 'http://localhost:${PORT}'`);
    console.log('======================================================');
});