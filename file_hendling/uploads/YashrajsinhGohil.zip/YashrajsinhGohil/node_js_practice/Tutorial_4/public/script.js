//* Functionality of adding and removing fields in html

//add and remove field functionality
const workExpTemp = `<div class="workExperience">
            <label for="companyName">Company Name &nbsp;</label>
            <input type="text" name="companyName" id="companyName">
            &nbsp;&nbsp;&nbsp;
            <label for="designation">Designation &nbsp;</label>
            <input type="text" name="designation" id="designation">
            &nbsp;&nbsp;&nbsp;
            <label for="fromDate">From &nbsp;</label>
            <input type="date" name="fromDate" id="fromDate">
            &nbsp;&nbsp;&nbsp;
            <label for="toDate">To &nbsp;</label>
            <input type="date" name="toDate" id="toDate">
            &nbsp;&nbsp;&nbsp;
        </div>`;

const experienceDetails = document.getElementById('experienceDetails');
const addExperience = document.getElementById('addExperience');
const removeExperience = document.getElementById('removeExperience');
addExperience.addEventListener('click', () => {
    experienceDetails.innerHTML += workExpTemp;
});

removeExperience.addEventListener('click', () => {
    const lastChild = experienceDetails.lastElementChild;
    if (experienceDetails.childElementCount > 3) {
        experienceDetails.removeChild(lastChild);
    } else {
        console.log('There are no elements to remove');
    }
});

//education add and remove field 
const educationDiv = document.getElementById('allEduDiv');
const addEducation = document.getElementById('addEdu');
const removeEducation = document.getElementById('removeEdu');

addEducation.addEventListener('click', () => {
    const fieldDetail = prompt('Enter field to have the new section for');
    educationDiv.innerHTML += `<div class="eduDetails">
                <input type="text" name="field" id="${fieldDetail.trim().toLocaleLowerCase()}" value="${fieldDetail}" class="noBrd" readonly><br><br>
                    <label for="university">University &nbsp;</label>
                    <input type="text" name="boardName_university" id="university">
                    &nbsp;&nbsp;
                    <label for="courseName">Course Name &nbsp;</label>
                    <input type="text" name="courseName" id="courseName">
                    &nbsp;&nbsp;
                    <label for="passingYear">Passing Year &nbsp;</label>
                    <input type="text" name="passingYear" id="passingYear">
                    &nbsp;&nbsp;
                    <label for="percentage">Percentage &nbsp;</label>
                    <input type="text" name="percentage" id="percentage">
                    &nbsp;&nbsp;
                <hr>
            </div>`;
});

removeEducation.addEventListener('click', () => {
    const lastChild = educationDiv.lastElementChild;
    console.log(educationDiv);
    if (educationDiv.childElementCount > 4) {
        educationDiv.removeChild(lastChild);
    } else {
        console.log('There are no elements to remove');
    }
});

//*Languages added dynamically

const languagesAdded = document.getElementById('languagesRows');
let langArr = ['Hindi', 'Gujarati', 'English', 'Marathi', 'Urdu'];

for (let i = 0; i < langArr.length; i++) {
    languagesAdded.innerHTML += `
        <tr>
            <td>${langArr[i]}</td>
            <td><input type="checkbox" name='${langArr[i]}[]' value='read' id='read_${langArr[i].toLowerCase()}' ></td>
            <td><input type="checkbox" name='${langArr[i]}[]' value='write' id='write_${langArr[i].toLowerCase()}'></td>
            <td><input type="checkbox" name='${langArr[i]}[]' value='speak' id='speak_${langArr[i].toLowerCase()}'></td>
        </tr>
    `;
};

//* Technologies Known

const technologiesKnown = document.getElementById('techKnown');
let techArr = ['PHP', 'MySQL', 'Laravel', 'Oracle', 'JavaScript'];

for (let i = 0; i < techArr.length; i++) {
    technologiesKnown.innerHTML += `
        <tr>
            <td>${techArr[i]}</td>
            <td><input type="radio" name="${techArr[i]}" value='Beginner' id="bigginer_${i + 1}"></td>
            <td><input type="radio" name="${techArr[i]}" value='Intermediate' id="intermediate_${i + 1}"></td>
            <td><input type="radio" name="${techArr[i]}" value='Expert' id="expert_${i + 1}"></td>
        </tr>
    `;
};

//* Add and remove references
// const referenceTemp = `
//             <div id="ref1" class="refDiv">
//                 <label for="refererName">Name &nbsp;</label>
//                 <input type="text" name="refererName" id="refererName">
//                 &nbsp;&nbsp;&nbsp;
//                 <label for="contactNumber">Contact Number &nbsp;</label>
//                 <input type="text" name="contactNumber" id="contactNumber">
//                 &nbsp;&nbsp;&nbsp;
//                 <label for="referRealtion">Relation &nbsp;</label>
//                 <input type="text" name="referRealtion" id="referRealtion">
//             </div>
// `;

// const addRefrence = document.getElementById('addRefrences');
// const removeRefrences = document.getElementById('removeRefrences');
// const referenceList = document.getElementById('referencesList');

// addRefrence.addEventListener('click', () => {
//     referenceList.innerHTML += referenceTemp;
// });

// removeRefrences.addEventListener('click', () => {
//     const lastChild = referenceList.lastElementChild;

//     if (lastChild) {
//         referenceList.removeChild(lastChild);
//     } else {
//         console.log('There are no fields left to remove!!');
//     }
// });