const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'job_application_details',
    waitForConnections: true,
    connectionLimit:    10,   
    queueLimit:         0
});

pool.getConnection()
    .then(connection => {
        console.log('Database connected successfully!');
        connection.release();
    })
    .catch(err => {
        console.log('Database connection failed!');
        console.log('error message:', err.message);
        console.log('check if MySQL is running or the .env variables are correct or not');
        
    });

module.exports = pool;