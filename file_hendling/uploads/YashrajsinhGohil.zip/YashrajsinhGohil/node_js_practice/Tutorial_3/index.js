require("dotenv").config();
const { error, log } = require("console");
const connection = require("./db");
const express = require("express");
const app = express();
const path = require("path");
const port = process.env.PORT || 3001;

app.set("view engine", "ejs");

app.use(express.static(path.join(__dirname, "public")));

app.get("/students", (req, res, next) => {
  const totalPageQuery = `SELECT COUNT(*) AS count FROM student_info`;
  connection.query(totalPageQuery, (err, totalPagesCount, fields) => {
    if (err) {
      throw new err();
    }
    let currentPage = Number(req.query.page) || 1;
    let totalRows = totalPagesCount[0].count;
    let limit = 100;
    let offset = (currentPage - 1) * 100;
    let totalPages = Math.ceil(totalRows / limit);
    console.log(typeof currentPage);

    if (currentPage < 1 || currentPage > totalPages) {
      currentPage = 1;
    }
    let sort = req.query.sort || "student_id";
    if (
      sort !== "student_id" ||
      sort !== "FullName" ||
      sort !== "Email" ||
      sort !== "date_of_birth" ||
      sort !== "City"
    ) {
      sort = "student_id";
    }
    let order = req.query.order || "ASC";
    if (order !== "ASC" || order !== "DESC") {
      order = "ASC";
    }

    const query = `SELECT 
                   student_id AS StudentRollno, 
                   CONCAT(first_name, ' ', last_name) AS FullName, 
                   gender AS Gender, phone_number AS Contact, 
                   email_id AS Email, 
                   address_line AS Address, 
                   DATE_FORMAT(date_of_birth, '%Y-%m-%d') AS date_of_birth, 
                   city AS City 
                   FROM student_info
                   ORDER BY ${sort} ${order} 
                   LIMIT ${offset}, ${limit};`;

    connection.query(query, (err, students, fields) => {
      if (err) {
        throw new error();
      }
      res.render("index", {
        currentPage,
        totalPages,
        sort,
        limit,
        offset,
        order,
        students,
      });
    });
  });
});

app.use((req, res, next) => {
  res.status(404).end("Sorry, we cannot find that! Please enter a valid route");
});

app.listen(port, () => console.log(`The app is listening at port ${port}`));
