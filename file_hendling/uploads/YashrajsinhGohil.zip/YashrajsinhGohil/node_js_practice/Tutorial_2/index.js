// let ejs = require('ejs');
let express = require('express');
let app = express();
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    res.render('index');
});

app.get('/cucucube', (req, res) => {
    res.render('cucucube');
});

app.get('/traffic-signal', (req, res) => {
    res.render('traffic_signal');
});

app.get('/form-validation', (req, res) => {
    res.render('form_validation');
});

app.get('/functions-display', (req, res) => {
    res.render('functions_display');
});

app.listen(8080, () => console.log('The port is running on 8080'));

/*
math string and data functions
*/
