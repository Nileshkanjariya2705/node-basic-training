require('dotenv').config();
const express = require('express');
const app = express();
const port = process.env.PORT || 3001;

const fs = require('fs');
console.log('Before file read');
fs.readFile('myfile.txt', 'utf8', (err, data) => {
  if (err) throw err;
  console.log('File contents:', data);
});
console.log('After file read');

app.get('/', (req, res) => {
    res.send('This is HERE Hello AMD!');
});

app.get('/login', (req, res) => {
    res.send({
        data: "This works like nodemon has we have used --watch command in terminal;"
    });
});

app.listen(port, () => {
    console.log(`The server is running at ${port}`);
});

console.log('Here from nodejs');
