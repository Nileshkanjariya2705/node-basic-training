require('dotenv').config();
const express = require('express');
const app = express();
const connection = require('./db');
const path = require('path');
const PORT = process.env.PORT;;
const getData = require('./public/script');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({extended: true}));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.get('/', async(req, res) => {
    res.render('comboBox');
});

app.get('/countries', async(req, res) => {
    const [data] = await (await connection).query('SELECT * FROM countryName;');
    res.send(data);
});

app.get('/states/:country_id', async(req, res) => {
    const country_id = req.params.country_id;
    const [statesList] = await (await connection).query(`SELECT * FROM statesName WHERE country_id = ?;`,[country_id]);
    res.send(statesList);
});

app.get('/cities/:state_id', async(req, res) => {
    const state_id = req.params.state_id;
    const [citiesList] = await (await connection).query(`SELECT * FROM cityName WHERE state_id = ?;`,[state_id]);
    res.send(citiesList);
});

app.listen(PORT, () => {
    console.log('========================================');
    console.log(`== The server is running on port:${PORT} ==`);
    console.log(`== Visit at 'http://localhost:${PORT}/'  ==`);
    console.log('========================================');
});
