const container = document.getElementById('container');
const button = document.getElementById('click');
const game = document.getElementById('startgame');
let score = document.getElementById('score');
const gameover = document.getElementById('gameover');
const finalScore = document.getElementById('finalScore');
const play = document.getElementById('play-pause');
const restart = document.getElementById('restart');

let i = 2;
let scoreIncrementer = 0;

function getRandomColor() {
  const r = Math.floor(Math.random() * 256);
  const g = Math.floor(Math.random() * 256); // 0-100%
  const b = Math.floor(Math.random() * 256); // 0-100%
  return `rgb(${r}, ${g}, ${b})`;
}

let counter = 0;
let t = 1;
function blockCreations () {
    
    //block creation logic
    container.innerHTML='';
    let counter = 0;
    let randomColor = getRandomColor();
    for(let outer = 0; outer < i; outer++) {
        const tr = document.createElement('tr');
        for(let inner  = 0; inner < i; inner++) {
            tr.innerHTML+= `<td class='box' style='background-color: ${randomColor};' id=${counter++}></td>`
        }
        container.appendChild(tr);
    }
    
    i++;


    const btn = document.querySelectorAll('.box');
    console.log(btn);
    
    let boxCell = Math.trunc(Math.random()*btn.length);

    const correctCell = document.getElementById(`${boxCell}`);
    correctCell.style.backgroundColor=randomColor;
    correctCell.style.opacity='.5';
    correctCell.addEventListener('click', blockCreations);
    ++scoreIncrementer;
    score.innerHTML = `Score: ${scoreIncrementer}`;

    game.style.display = 'none';
    container.style.display = 'table';
}

function timer() {
    //timer logic
    const timer = document.getElementById('timer');
    let num = 15;
    let isPaused = false;

    let timerInterval = setInterval(() => {
        timer.innerHTML = `Remaining time : ${num - 1}`;
        num--;
        // console.log(typeof(num));
        play.addEventListener('click', () => {
            if(play.innerText == 'Pause') {
                let pauseInterval = setInterval(() => {
                       console.log("This is paused");
                        
                }, 1000);
                if(play.innerText == "play") {
                    clearInterval(pauseInterval);
                }
            } 
        })
        if(num == 0) {
            clearInterval(timerInterval);
            finalScore.innerHTML = `Final score is : ${scoreIncrementer}`; 
            container.style.display = 'none';
            gameover.style.display = 'inline-block';
        }
    }, 1000, num, isPaused);
}

button.addEventListener('click', timer);

button.addEventListener('click', blockCreations);

// restart.addEventListener('click', timer);

// restart.addEventListener('click', blockCreations);
