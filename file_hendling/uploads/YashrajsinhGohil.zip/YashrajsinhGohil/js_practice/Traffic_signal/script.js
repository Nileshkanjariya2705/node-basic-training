const northGreen = document.getElementById('north-green');
const northRed = document.getElementById('north-red');
const northYellow = document.getElementById('north-yellow');
const eastRed = document.getElementById('east-red');
const eastYellow = document.getElementById('east-yellow');
const eastGreen = document.getElementById('east-green');
const westRed = document.getElementById('west-red');
const westYellow = document.getElementById('west-yellow');
const westGreen = document.getElementById('west-green');
const southRed = document.getElementById('south-red');
const southYellow = document.getElementById('south-yellow');
const southGreen = document.getElementById('south-green');
const timerCounter = document.getElementById('timerCounter');

let counter = 1;
const timer = setInterval(() => {
    timerCounter.innerText = counter;
    counter++
    if(counter >= 40) {
        counter = 0;
    }
}, 1000, counter);




//visible lights;
northYellow.style.visibility = 'hidden';
northRed.style.visibility = 'hidden';
eastYellow.style.visibility = 'hidden';
eastGreen.style.visibility = 'hidden';
southGreen.style.visibility = 'hidden';
southYellow.style.visibility = 'hidden';
westGreen.style.visibility = 'hidden';
westYellow.style.visibility = 'hidden';


function trafficSignal() {
    setTimeout(() => {
        northGreen.style.visibility = 'hidden';
        northYellow.style.visibility = 'visible';
    }, 7000)
    
    setTimeout(() => {
        northYellow.style.visibility = 'hidden';
        northRed.style.visibility = 'visible';
        eastRed.style.visibility = 'hidden';
        eastGreen.style.visibility = 'visible';
    }, 10000)
    
    setTimeout(() => {
        eastYellow.style.visibility = 'visible';
        eastGreen.style.visibility = 'hidden';
    }, 17000);
    
    setTimeout(() => {
        eastYellow.style.visibility = 'hidden';
        eastRed.style.visibility = 'visible';
        southRed.style.visibility = 'hidden';
        southGreen.style.visibility = 'visible';
    }, 20000);
    
    setTimeout(() => {
        southYellow.style.visibility = 'visible';
        southGreen.style.visibility = 'hidden';
    }, 27000);
    
    setTimeout(() => {
        southRed.style.visibility = 'visible';
        southYellow.style.visibility = 'hidden';
        westRed.style.visibility = 'hidden';
        westGreen.style.visibility = 'visible';
    }, 30000);
    
    setTimeout(() => {
        westGreen.style.visibility = 'hidden';
        westYellow.style.visibility = 'visible';
    }, 37000);

    setTimeout(() => {
        westYellow.style.visibility = 'hidden';
        westRed.style.visibility = 'visible';
        northGreen.style.visibility = 'visible';
        northRed.style.visibility = 'hidden';
    }, 40000);
};


trafficSignal();

setInterval(trafficSignal, 40000);
