document.getElementById("jobForm").addEventListener("submit", function (e) {

    let errors = [];

    let firstName = document.getElementById("firstName").value.trim();
    let lastName = document.getElementById("lastName").value.trim();
    let email = document.getElementById("email").value.trim();
    let phone = document.getElementById("phone").value.trim();
    let zip = document.getElementById("zip").value.trim();
    let dob = document.getElementById("dob").value;

    let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let phonePattern = /^[0-9]{10}$/;
    let zipPattern = /^[0-9]{6}$/;
    let yearPattern = /^[0-9]{4}$/;
    let percentPattern = /^(100|[0-9]{1,2})(\.[0-9]{1,2})?$/;

    if (firstName === "") errors.push("First name required");
    if (lastName === "") errors.push("Last name required");

    if (!emailPattern.test(email)) errors.push("Invalid email");

    if (!phonePattern.test(phone)) errors.push("Phone must be 10 digits");

    if (!zipPattern.test(zip)) errors.push("Zip must be 6 digits");

    if (dob === "") errors.push("Date of birth required");


    /* EDUCATION VALIDATION */

    document.querySelectorAll(".educationRow").forEach(row => {

        let course = row.querySelector(".course").value.trim();
        let university = row.querySelector(".university").value.trim();
        let year = row.querySelector(".year").value.trim();
        let percentage = row.querySelector(".percentage").value.trim();

        if (course === "") errors.push("Course required");
        if (university === "") errors.push("University required");

        if (!yearPattern.test(year))
            errors.push("Passing year must be 4 digits");

        if (!percentPattern.test(percentage))
            errors.push("Percentage must be between 0-100");

    });


    /* WORK EXPERIENCE */

    document.querySelectorAll(".workRow").forEach(row => {

        let company = row.querySelector(".company").value.trim();
        let designation = row.querySelector(".workDesignation").value.trim();
        let from = row.querySelector(".fromDate").value;
        let to = row.querySelector(".toDate").value;

        if (company === "") errors.push("Company name required");

        if (designation === "") errors.push("Designation required");

        if (from !== "" && to !== "" && new Date(from) > new Date(to))
            errors.push("From date cannot be after To date");

    });


    /* REFERENCES */

    document.querySelectorAll(".refContact").forEach(contact => {

        if (contact.value !== "" && !phonePattern.test(contact.value))
            errors.push("Reference contact must be 10 digits");

    });


    /* CTC */

    let currentCTC = document.getElementById("currentCTC").value;
    let expectedCTC = document.getElementById("expectedCTC").value;

    if (currentCTC !== "" && isNaN(currentCTC))
        errors.push("Current CTC must be number");

    if (expectedCTC !== "" && isNaN(expectedCTC))
        errors.push("Expected CTC must be number");



    if (errors.length > 0) {
        e.preventDefault();
        alert(errors.join("\n"));
    }

});



/* ADD REMOVE EDUCATION */

document.addEventListener("click", function (e) {

    if (e.target.classList.contains("addEducation")) {

        let container = document.getElementById("educationContainer");
        let row = document.querySelector(".educationRow").cloneNode(true);

        row.querySelectorAll("input").forEach(i => i.value = "");

        container.appendChild(row);

    }

    if (e.target.classList.contains("removeEducation")) {

        let rows = document.querySelectorAll(".educationRow");

        if (rows.length > 1) {
            e.target.parentElement.remove();
        }

    }



    /* ADD REMOVE WORK */

    if (e.target.classList.contains("addWork")) {

        let container = document.getElementById("workContainer");
        let row = document.querySelector(".workRow").cloneNode(true);

        row.querySelectorAll("input").forEach(i => i.value = "");

        container.appendChild(row);

    }

    if (e.target.classList.contains("removeWork")) {

        let rows = document.querySelectorAll(".workRow");

        if (rows.length > 1) {
            e.target.parentElement.remove();
        }

    }

});